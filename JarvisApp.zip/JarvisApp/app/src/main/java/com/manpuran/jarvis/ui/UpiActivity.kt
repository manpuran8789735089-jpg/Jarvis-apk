package com.manpuran.jarvis.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.manpuran.jarvis.R
import com.manpuran.jarvis.util.UpiHelper

class UpiActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upi)

        val input = findViewById<EditText>(R.id.editUpiId)
        val status = findViewById<TextView>(R.id.textUpiStatus)

        status.text = UpiHelper.getSavedUpiId(this)?.let { "Saved UPI ID: $it" }
            ?: "No UPI ID saved yet"

        findViewById<Button>(R.id.btnSaveUpi).setOnClickListener {
            val vpa = input.text.toString().trim()
            if (!UpiHelper.isValidVpaFormat(vpa)) {
                Toast.makeText(this, "Enter a valid UPI ID (e.g. name@bank)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            UpiHelper.saveUpiId(this, vpa)
            status.text = "Saved UPI ID: $vpa"
        }

        findViewById<Button>(R.id.btnCheckUpi).setOnClickListener {
            status.text = UpiHelper.getSavedUpiId(this)?.let { "Saved UPI ID: $it" }
                ?: "No UPI ID saved yet"
        }
    }
}
