package com.manpuran.jarvis.api

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Thin wrapper around the Anthropic Messages API.
 * IMPORTANT: never hardcode the API key in source. Read it from
 * local encrypted storage or BuildConfig injected at build time via
 * a GitHub Actions secret (see .github/workflows/build.yml).
 */
object ClaudeApiClient {

    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-sonnet-4-6"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // TODO: replace with a secure key source (EncryptedSharedPreferences / Android Keystore),
    // never commit a real key to the repo.
    var apiKey: String = ""

    fun sendMessage(userText: String, languageHint: String, memoryContext: String): String {
        val systemPrompt = buildSystemPrompt(languageHint, memoryContext)

        val body = JSONObject().apply {
            put("model", MODEL)
            put("max_tokens", 1024)
            put("system", systemPrompt)
            put("messages", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("content", userText)
                }
            ))
        }

        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                return "Sorry, I couldn't reach the assistant service right now."
            }
            val json = JSONObject(responseBody)
            val contentArray = json.optJSONArray("content") ?: return ""
            val builder = StringBuilder()
            for (i in 0 until contentArray.length()) {
                val block = contentArray.getJSONObject(i)
                if (block.optString("type") == "text") {
                    builder.append(block.optString("text"))
                }
            }
            return builder.toString()
        }
    }

    private fun buildSystemPrompt(languageHint: String, memoryContext: String): String {
        val languageInstruction = if (languageHint == "hi-IN")
            "Reply in Hindi (Devanagari)." else "Reply in English."
        return """
            You are Jarvis, a helpful voice assistant on the user's Android phone.
            $languageInstruction
            Keep spoken replies short and natural (this will be read aloud by TTS).
            You can discuss general knowledge, weather, and directions.
            Known saved memories about the user:
            $memoryContext
        """.trimIndent()
    }
}
