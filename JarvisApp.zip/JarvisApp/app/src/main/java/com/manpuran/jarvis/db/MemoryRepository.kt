package com.manpuran.jarvis.db

import android.content.Context

/**
 * Handles "remember that ..." / "yaad rakho ki ..." commands and stores
 * facts ONLY in the local Room database on-device (never sent to the cloud
 * except as short context back to Claude for the current reply).
 */
class MemoryRepository(context: Context) {

    private val dao = AppDatabase.getInstance(context).memoryDao()

    private val hindiTriggers = listOf("याद रखो कि", "याद रखना कि", "याद रखो")
    private val englishTriggers = listOf("remember that", "remember this", "keep in mind that")

    suspend fun tryHandleMemoryCommand(text: String): Boolean {
        val trigger = (hindiTriggers + englishTriggers).firstOrNull { text.contains(it, ignoreCase = true) }
            ?: return false

        val fact = text.substringAfter(trigger).trim().ifBlank { text }
        dao.insert(MemoryEntity(fact = fact))
        return true
    }

    suspend fun getAllAsContext(): String {
        val facts = dao.getAll()
        if (facts.isEmpty()) return "(none yet)"
        return facts.joinToString("\n") { "- ${it.fact}" }
    }
}
