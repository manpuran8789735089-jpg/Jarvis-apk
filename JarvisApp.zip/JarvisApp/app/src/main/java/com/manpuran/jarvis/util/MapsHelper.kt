package com.manpuran.jarvis.util

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Opens the device's Google Maps app for a place search or navigation.
 * No custom API key required — uses the standard geo: intent.
 */
object MapsHelper {

    fun searchPlace(context: Context, query: String) {
        val uri = Uri.parse("geo:0,0?q=" + Uri.encode(query))
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.google.android.apps.maps")
        }
        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
        } else {
            // Fallback to browser-based maps
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(
                "https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query)
            )))
        }
    }

    fun navigateTo(context: Context, destination: String) {
        val uri = Uri.parse("google.navigation:q=" + Uri.encode(destination))
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.google.android.apps.maps")
        }
        context.startActivity(intent)
    }
}
