package com.manpuran.jarvis.util

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Fetches current weather via OpenWeatherMap free tier.
 * Get a free API key at https://openweathermap.org/api and store it securely
 * (do not commit it to the repo — inject via GitHub Actions secret / local.properties).
 */
object WeatherHelper {

    private val client = OkHttpClient()
    var apiKey: String = ""

    fun getWeather(lat: Double, lon: Double): String {
        val url = "https://api.openweathermap.org/data/2.5/weather" +
            "?lat=$lat&lon=$lon&appid=$apiKey&units=metric&lang=hi"

        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return "मौसम जानकारी अभी उपलब्ध नहीं है।"
            val json = JSONObject(response.body?.string().orEmpty())
            val temp = json.getJSONObject("main").getDouble("temp")
            val desc = json.getJSONArray("weather").getJSONObject(0).getString("description")
            return "अभी तापमान ${temp}°C है, $desc"
        }
    }
}
