package com.manpuran.jarvis.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memory")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fact: String,
    val savedAt: Long = System.currentTimeMillis()
)
