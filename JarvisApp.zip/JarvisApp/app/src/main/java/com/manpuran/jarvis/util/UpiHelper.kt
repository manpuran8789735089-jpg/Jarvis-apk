package com.manpuran.jarvis.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * IMPORTANT: This app never asks for, sees, or stores a UPI PIN.
 * It only stores the user's UPI ID (VPA, e.g. name@bank) — an identifier,
 * not a secret — in encrypted local storage. Actual payments are handed
 * off to the user's own installed UPI app (GPay/PhonePe/Paytm) via the
 * standard "upi://pay" deep link, where the PIN is entered inside that
 * trusted, RBI-regulated app — never inside Jarvis.
 */
object UpiHelper {

    private const val PREFS_NAME = "jarvis_upi_secure_prefs"
    private const val KEY_UPI_ID = "saved_upi_id"

    private fun prefs(context: Context) =
        EncryptedSharedPreferences.create(
            context,
            PREFS_NAME,
            MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

    fun saveUpiId(context: Context, vpa: String) {
        prefs(context).edit().putString(KEY_UPI_ID, vpa).apply()
    }

    fun getSavedUpiId(context: Context): String? =
        prefs(context).getString(KEY_UPI_ID, null)

    fun isValidVpaFormat(vpa: String): Boolean =
        Regex("^[\\w.\\-]{2,256}@[a-zA-Z]{2,64}$").matches(vpa)

    /** Launches the user's own UPI app to pay; PIN is entered there, not in Jarvis. */
    fun startPayment(context: Context, payeeVpa: String, payeeName: String, amount: String, note: String) {
        val uri = Uri.parse(
            "upi://pay?pa=$payeeVpa&pn=${Uri.encode(payeeName)}&am=$amount&cu=INR&tn=${Uri.encode(note)}"
        )
        val intent = Intent(Intent.ACTION_VIEW, uri)
        context.startActivity(Intent.createChooser(intent, "Pay with"))
    }
}
