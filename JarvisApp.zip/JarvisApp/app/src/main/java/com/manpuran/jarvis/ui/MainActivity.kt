package com.manpuran.jarvis.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.manpuran.jarvis.R
import com.manpuran.jarvis.service.OverlayService
import com.manpuran.jarvis.service.VoiceAssistantService

/**
 * Main entry screen.
 * - Requests only RECORD_AUDIO (standard mic permission, nothing extra).
 * - Starts the foreground VoiceAssistantService (STT -> Claude API -> TTS loop).
 * - Starts the OverlayService for the 3D home-screen presence.
 */
class MainActivity : AppCompatActivity() {

    private val micPermissionCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ensureMicPermission()

        findViewById<android.widget.Button>(R.id.btnStartAssistant).setOnClickListener {
            startVoiceService()
        }

        findViewById<android.widget.Button>(R.id.btnOverlay).setOnClickListener {
            ensureOverlayPermission()
        }

        findViewById<android.widget.Button>(R.id.btnDeveloperMode).setOnClickListener {
            startActivity(Intent(this, CodeGenActivity::class.java))
        }

        findViewById<android.widget.Button>(R.id.btnUpi).setOnClickListener {
            startActivity(Intent(this, UpiActivity::class.java))
        }
    }

    private fun ensureMicPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO), micPermissionCode
            )
        }
    }

    private fun startVoiceService() {
        val intent = Intent(this, VoiceAssistantService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun ensureOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            startService(Intent(this, OverlayService::class.java))
        }
    }
}
