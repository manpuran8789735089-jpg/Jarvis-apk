package com.manpuran.jarvis.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.manpuran.jarvis.R
import com.manpuran.jarvis.api.ClaudeApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Developer mode" — ask Jarvis to generate code / a project structure,
 * then save it as a real file in the app's external files directory
 * (visible under Android/data/com.manpuran.jarvis/files/ in a file manager,
 * from where it can be shared or pushed to GitHub via Termux/git app).
 */
class CodeGenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_codegen)

        val promptInput = findViewById<EditText>(R.id.editCodePrompt)
        val fileNameInput = findViewById<EditText>(R.id.editFileName)
        val output = findViewById<TextView>(R.id.textCodeOutput)

        findViewById<Button>(R.id.btnGenerateCode).setOnClickListener {
            val prompt = promptInput.text.toString()
            lifecycleScope.launch {
                output.text = "Generating..."
                val code = withContext(Dispatchers.IO) {
                    ClaudeApiClient.sendMessage(
                        userText = "Write code for: $prompt. Return only the code, no explanation.",
                        languageHint = "en-IN",
                        memoryContext = "(none)"
                    )
                }
                output.text = code

                val fileName = fileNameInput.text.toString().ifBlank { "Generated.kt" }
                val dir = getExternalFilesDir(null)
                val file = File(dir, fileName)
                file.writeText(code)
            }
        }
    }
}
