package com.manpuran.jarvis.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface MemoryDao {
    @Insert
    suspend fun insert(entity: MemoryEntity)

    @Query("SELECT * FROM memory ORDER BY savedAt DESC")
    suspend fun getAll(): List<MemoryEntity>
}
