package com.manpuran.jarvis.service

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.manpuran.jarvis.JarvisApplication
import com.manpuran.jarvis.R
import com.manpuran.jarvis.api.ClaudeApiClient
import com.manpuran.jarvis.db.MemoryRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Foreground service that runs the full audio-to-audio loop:
 * Mic -> SpeechRecognizer (STT) -> Claude API -> TextToSpeech (TTS) -> back to listening.
 * Uses only the single RECORD_AUDIO permission already granted by MainActivity.
 */
class VoiceAssistantService : Service(), TextToSpeech.OnInitListener {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var memoryRepository: MemoryRepository
    private val scope = CoroutineScope(Dispatchers.IO)
    private var currentLanguage = "hi-IN" // default Hindi, auto-switches per query

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        tts = TextToSpeech(this, this)
        memoryRepository = MemoryRepository(applicationContext)
        setupRecognizer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startListening()
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, JarvisApplication.VOICE_CHANNEL_ID)
            .setContentTitle("Jarvis is listening")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .build()
    }

    private fun setupRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spokenText = matches?.firstOrNull().orEmpty()
                if (spokenText.isNotBlank()) {
                    handleUserSpeech(spokenText)
                } else {
                    startListening()
                }
            }

            override fun onError(error: Int) {
                // Retry listening loop
                startListening()
            }

            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
    }

    private fun startListening() {
        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // Recognizer auto-detects between Hindi and English based on device locale list
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, currentLanguage)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }
        speechRecognizer.startListening(recognizerIntent)
    }

    private fun handleUserSpeech(text: String) {
        currentLanguage = if (containsDevanagari(text)) "hi-IN" else "en-IN"

        scope.launch {
            // Local memory commands: "yaad rakho ki ..." / "remember that ..."
            if (memoryRepository.tryHandleMemoryCommand(text)) {
                speak(if (currentLanguage == "hi-IN") "ठीक है, मैंने याद रख लिया।" else "Got it, I'll remember that.")
                return@launch
            }

            val savedMemories = memoryRepository.getAllAsContext()
            val reply = ClaudeApiClient.sendMessage(
                userText = text,
                languageHint = currentLanguage,
                memoryContext = savedMemories
            )
            speak(reply)
        }
    }

    private fun containsDevanagari(text: String): Boolean =
        text.any { it.code in 0x0900..0x097F }

    private fun speak(text: String) {
        val locale = if (currentLanguage == "hi-IN") Locale("hi", "IN") else Locale.US
        tts.language = locale
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        // Resume listening after speaking finishes (handled via UtteranceProgressListener in production)
        startListening()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
