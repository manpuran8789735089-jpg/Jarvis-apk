package com.manpuran.jarvis.service

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import com.manpuran.jarvis.R

/**
 * Draws a small floating glowing orb over the home screen (like Jarvis's HUD presence).
 * Requires SYSTEM_ALERT_WINDOW, granted via MainActivity before this service starts.
 * Tapping the orb starts/stops the VoiceAssistantService.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var orbView: ImageView

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        orbView = ImageView(this).apply {
            setImageResource(R.drawable.jarvis_orb)
        }

        val params = WindowManager.LayoutParams(
            120, 120,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 200
        }

        windowManager.addView(orbView, params)
        animateGlow()

        orbView.setOnClickListener {
            val intent = Intent(this, VoiceAssistantService::class.java)
            startForegroundService(intent)
        }
    }

    private fun animateGlow() {
        // Simple pulsing "3D glow" effect via scale/alpha animation.
        val scaleUp = ObjectAnimator.ofFloat(orbView, "scaleX", 1f, 1.15f, 1f)
        val scaleUpY = ObjectAnimator.ofFloat(orbView, "scaleY", 1f, 1.15f, 1f)
        listOf(scaleUp, scaleUpY).forEach {
            it.duration = 1400
            it.repeatCount = ValueAnimator.INFINITE
            it.start()
        }
    }

    override fun onDestroy() {
        if (::orbView.isInitialized) {
            windowManager.removeView(orbView)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
