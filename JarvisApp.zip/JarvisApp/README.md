# Jarvis — Android Voice Assistant

Master prompt से बना पूरा project structure। नीचे दी गई सारी फाइलें एक काम करने वाला
skeleton बनाती हैं — इसमें असली API key डालकर, GitHub पर push करके, GitHub Actions
से APK cloud में build होगा (PC की ज़रूरत नहीं)।

## Folder Structure

```
JarvisApp/
├── build.gradle.kts
├── settings.gradle.kts
├── .github/workflows/build.yml        <- cloud APK build (GitHub Actions)
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/manpuran/jarvis/
        │   ├── JarvisApplication.kt
        │   ├── ui/
        │   │   ├── MainActivity.kt        <- home screen, permission requests
        │   │   ├── CodeGenActivity.kt      <- "developer mode": generate & save code files
        │   │   └── UpiActivity.kt          <- UPI ID add/check/save (no PIN ever)
        │   ├── service/
        │   │   ├── VoiceAssistantService.kt <- STT -> Claude API -> TTS loop
        │   │   └── OverlayService.kt        <- 3D glowing home-screen orb
        │   ├── api/
        │   │   └── ClaudeApiClient.kt       <- Anthropic Messages API wrapper
        │   ├── db/
        │   │   ├── MemoryEntity.kt          <- Room table for "remember this" facts
        │   │   ├── MemoryDao.kt
        │   │   ├── AppDatabase.kt
        │   │   └── MemoryRepository.kt      <- detects remember-commands, local-only
        │   └── util/
        │       ├── WeatherHelper.kt         <- OpenWeatherMap
        │       ├── MapsHelper.kt            <- opens Google Maps via intent
        │       └── UpiHelper.kt             <- encrypted VPA storage + payment deep link
        └── res/
            ├── layout/  (activity_main, activity_upi, activity_codegen)
            ├── values/  (colors, strings, themes)
            └── drawable/jarvis_orb.xml
```

## Phone-only build steps (कोई PC नहीं चाहिए)

1. इस पूरे folder को GitHub पर एक नए repo में push करें (Termux + git, या किसी Git app से)।
2. Repo Settings → Secrets and variables → Actions में जाकर `CLAUDE_API_KEY` नाम से secret जोड़ें।
3. `main` branch पर push करते ही GitHub Actions अपने आप APK build करेगा।
4. Actions tab → latest run → Artifacts में `jarvis-debug-apk` मिलेगा, वही download करके फोन में install करें।

## अभी जो अधूरा / TODO है

- `ClaudeApiClient.apiKey` और `WeatherHelper.apiKey` को runtime पर secure storage
  (EncryptedSharedPreferences) से लोड करने वाला setup screen जोड़ना बाकी है — अभी
  खाली रखा गया है ताकि कोई real key repo में commit न हो जाए।
- TTS पूरा बोलने के बाद ही अगली सुनवाई शुरू हो, इसके लिए `UtteranceProgressListener`
  जोड़ना (अभी simplified लूप है)।
- Launcher icon (`ic_launcher`) अभी default है — असली 3D Jarvis आइकॉन बाद में जोड़ें।

## UPI सुरक्षा

App कभी भी PIN नहीं माँगता। सिर्फ UPI ID (VPA) encrypted रूप में save होती है, और
भुगतान हमेशा फोन में installed असली UPI app (GPay/PhonePe/Paytm) के ज़रिए होता है।
